# Add tkinter system dependency
Before running the bot, ensure you have tkinter installed on your system:
sudo apt-get install -y python3-tk  # For Ubuntu/Debian
sudo dnf install -y python3-tkinter  # For Fedora/RHEL
brew install python-tk  # For macOS with Homebrew
